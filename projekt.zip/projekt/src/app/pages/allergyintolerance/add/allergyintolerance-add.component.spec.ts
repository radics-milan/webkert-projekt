import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllergyintoleranceAddComponent } from './allergyintolerance-add.component';

describe('AllegyintoleranceAddComponent', () => {
  let component: AllergyintoleranceAddComponent;
  let fixture: ComponentFixture<AllergyintoleranceAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllergyintoleranceAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllergyintoleranceAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
