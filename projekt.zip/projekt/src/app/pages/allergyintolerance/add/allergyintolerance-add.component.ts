import { Component} from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { FormControl, FormGroup, Validators } from '@angular/forms';
 
@Component({
  selector: 'app-allergyintolerance-add',
  templateUrl: './allergyintolerance-add.component.html',
  styleUrls: ['./allergyintolerance-add.component.scss'],

})

export class AllergyintoleranceAddComponent{
  form: FormGroup = new FormGroup({
    resourceType: new FormControl('AllergyIntolerance'),
    text:  new FormGroup({
        status: new FormControl(''),
        div: new FormControl('')
    }),
    type: new FormControl(''),
    criticality: new FormControl('unable-to-access'),
    patient: new FormControl('', Validators.required),
    encounter: new FormControl(''),
    onsetDateTime: new FormControl(''),
    onsetAge: new FormControl(''),
    onsetString: new FormControl(''),
    recordedDate: new FormControl(''),
    recorder: new FormControl(''),
    asserter: new FormControl(''),
    lastOccurrence: new FormControl(''),
  });

  constructor(public dialogRef: MatDialogRef<AllergyintoleranceAddComponent>) { }

}
