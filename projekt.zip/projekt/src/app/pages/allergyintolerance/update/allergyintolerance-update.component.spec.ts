import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllergyintoleranceUpdateComponent } from './allergyintolerance-update.component';

describe('AllergyintoleranceUpdateComponent', () => {
  let component: AllergyintoleranceUpdateComponent;
  let fixture: ComponentFixture<AllergyintoleranceUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllergyintoleranceUpdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllergyintoleranceUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
