import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Allergyintolerance } from './../../model/model';

@Component({
  selector: 'app-allergyintolerance-card',
  templateUrl: './allergyintolerance-card.component.html',
  styleUrls: ['./allergyintolerance-card.component.scss']
})
export class AllergyintoleranceCardComponent {
  @Input() allergyintolerance ?: Allergyintolerance;
  @Output() callDelete = new EventEmitter<string>();

}
