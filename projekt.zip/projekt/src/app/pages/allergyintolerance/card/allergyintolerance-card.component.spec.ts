import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllergyintoleranceCardComponent } from './allergyintolerance-card.component';

describe('AllergyintoleranceCardComponent', () => {
  let component: AllergyintoleranceCardComponent;
  let fixture: ComponentFixture<AllergyintoleranceCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllergyintoleranceCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllergyintoleranceCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
