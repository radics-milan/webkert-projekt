import { HighLightModule } from './../../directive/high-light.module';
import { MatButtonModule } from '@angular/material/button';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllergyintoleranceCardComponent } from './allergyintolerance-card.component';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [AllergyintoleranceCardComponent],
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    HighLightModule
  ],
  exports: [AllergyintoleranceCardComponent]
})
export class AllergyintoleranceCardModule { }
