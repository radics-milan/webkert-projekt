import { Allergyintolerance } from './../model/model';
import { AngularFirestore,  CollectionReference, Query  } from '@angular/fire/firestore';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FbServiceService {

  constructor(private afs: AngularFirestore) { }

  getByPatientAsc(collectionName: string): Observable<Allergyintolerance[]>{
    return this.afs.collection(collectionName, ref => {
      let query: CollectionReference | Query = ref;
      query = query.orderBy('patient', 'asc');
      return query;
    } ).valueChanges() as Observable<Allergyintolerance[]>;
  }

  getByPatientDesc(collectionName: string): Observable<Allergyintolerance[]>{
    return this.afs.collection(collectionName, ref => {
      let query: CollectionReference | Query = ref;
      query = query.orderBy('patient', 'desc');
      return query;
    } ).valueChanges() as Observable<Allergyintolerance[]>;
  }

  getCriticalityLow(collectionName: string): Observable<Allergyintolerance[]>{
    return this.afs.collection(collectionName, ref => {
      let query: CollectionReference | Query = ref;
      query = query.where('criticality', '==', 'low').orderBy('patient','asc');
      return query;
    } ).valueChanges() as Observable<Allergyintolerance[]>;
  }

  getCriticalityHigh(collectionName: string): Observable<Allergyintolerance[]>{
    return this.afs.collection(collectionName, ref => {
      let query: CollectionReference | Query = ref;
      query = query.where('criticality', '==', 'high').orderBy('patient','asc');
      return query;
    } ).valueChanges() as Observable<Allergyintolerance[]>;
  }

  getTypeAllergy(collectionName: string): Observable<Allergyintolerance[]>{
    return this.afs.collection(collectionName, ref => {
      let query: CollectionReference | Query = ref;
      query = query.where('type', '==', 'allergy').orderBy('patient','asc');
      return query;
    } ).valueChanges() as Observable<Allergyintolerance[]>;
  }

  getTypeIntolerance(collectionName: string): Observable<Allergyintolerance[]>{
    return this.afs.collection(collectionName, ref => {
      let query: CollectionReference | Query = ref;
      query = query.where('type', '==', 'intolerance').orderBy('patient','asc');
      return query;
    } ).valueChanges() as Observable<Allergyintolerance[]>;
  }


  async add(collectionName: string, data: Allergyintolerance, id?:string): Promise<string> {
    const uid = id? id: this.afs.createId();
    data.id = uid;
    await this.afs.collection(collectionName).doc(uid).set(data);
    return uid;
  }


  update(collectionName: string, id: string, data: any){
    return this.afs.collection(collectionName).doc(id).update(data);
  }

  delete(collectionName: string, id: string){
    return this.afs.collection(collectionName).doc(id).delete();
  }
}
