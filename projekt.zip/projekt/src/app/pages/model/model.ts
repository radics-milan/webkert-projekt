export interface Allergyintolerance {
    resourceType?: string;
    id: string;
    text?: Text;
    identifier?: Identifier[];
    clinicalStatus?: CodeableConcept;
    verificationStatus?: CodeableConcept;
    type?: 'allergy' | 'intolerance';
    category?: String[];
    criticality?: 'low' | 'high' | 'unable-to-access';
    code?: CodeableConcept;
    patient: Reference;
    encounter?: Reference;
    onsetDateTime?: string;
    onsetAge?: string;
    onsetPeriod?: Period;
    onsetRange?: Range;
    onsetString?: string;
    recordedDate?: string;
    recorder?: Reference;
    asserter?: Reference;
    lastOccurrence?: string;
    note?: Annotation[];
    reaction?: Reaction[];
}

export interface Identifier {
    use?: 'usual' | 'official' | 'temp' | 'secondary' | 'old';
    type?: CodeableConcept;
    system?: string;
    value?: string;
    period?: Period;
    assigner?: Reference;
}

export interface CodeableConcept {
    coding?: Coding[];
    text?: string;
}

export interface Coding {
    system?: string;
    version?: string;
    code?: string;
    display?: string;
    userSelected?: boolean;
}

export interface Reference {
    reference?: string;
    type?: string;
    identifier?: Identifier;
    display?: string;
}

export interface Period {
    start?: string;
    end?: string;
}

export interface Range {
    low?: SimpleQuantity;
    high?: SimpleQuantity;
}

export interface SimpleQuantity {
    value?: number;
    unit?: string;
    system?: string;
    code?: string;
}

export interface Annotation {
    authorReference?: Reference;
    authorString?: string;
    time?: string;
    text: string;
}

export interface Reaction {
    substance?: CodeableConcept;
    manifestation: CodeableConcept[];
    description?: string;
    onset?: string;
    severity?: 'mild' | 'moderate' | 'severe';
    exposureRoute?: CodeableConcept;
    note?: Annotation[];
}

export interface Text {
    status?: string;
    div?: string;
}