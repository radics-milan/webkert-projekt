import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component } from '@angular/core';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent {
  form: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password1: new FormControl('',[Validators.required, Validators.minLength(6)]),
    password2: new FormControl('',[Validators.required, Validators.minLength(6)])
  });

  error = false;

  constructor(private router: Router, private authService: AuthService) { }

  registration() : void{
    this.error = false;
    if(this.form.valid){
      if(this.form.value.password1 === this.form.value.password2){
        this.authService.registration(this.form.value.email, this.form.value.password1);
        this.router.navigateByUrl("/login");
        return;
      }
    }
    this.error = true;
  }
}

