import { AllergyintoleranceAddComponent } from '../allergyintolerance/add/allergyintolerance-add.component';
import { FbServiceService } from './../service/fb-service.service';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Allergyintolerance } from '../model/model';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { AllergyintoleranceUpdateComponent } from './../allergyintolerance/update/allergyintolerance-update.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnDestroy {
  allergyintolerances: Allergyintolerance[] | null = null;
  pageState='';
  getSub : Subscription | null = null;

  constructor(private dialog: MatDialog, private service : FbServiceService) { }

  ngOnInit(): void {
    this.getByPatientAsc();
  }

  ngOnDestroy():void{
    if(this.getSub){
      this.getSub.unsubscribe();
    }
  }

  getByPatientAsc(): void{
    this.pageState = 'loading'
    this.getSub = this.service.getByPatientAsc('allergyintolerances').subscribe(
      result=>{
        if(result?.length > 0){
          this.allergyintolerances = result;
          this.pageState='data';
        } else{
          this.pageState = 'noData';
        }
      },
       err=>{
         console.log(err);
         this.pageState= '';
      }
    );
  }

  getByPatientDesc(): void{
    this.pageState = 'loading'
    this.getSub = this.service.getByPatientDesc('allergyintolerances').subscribe(
      result=>{
        if(result?.length > 0){
          this.allergyintolerances = result;
          this.pageState='data';
        } else{
          this.pageState = 'noData';
        }
      },
       err=>{
         console.log(err);
         this.pageState= '';
      }
    );
  }

  getCriticalityLow() : void{
    this.pageState = 'loading'
    this.getSub =  this.service.getCriticalityLow('allergyintolerances').subscribe(
      result=>{
        if(result?.length > 0){
          this.allergyintolerances = result;
          this.pageState='data';
        } else{
          this.pageState = 'noData';
        }
      },
       err=>{
         console.log(err);
         this.pageState= '';
      }
    );
  }

  getCriticalityHigh() : void{
    this.pageState = 'loading'
    this.getSub =  this.service.getCriticalityHigh('allergyintolerances').subscribe(
      result=>{
        if(result?.length > 0){
          this.allergyintolerances = result;
          this.pageState='data';
        } else{
          this.pageState = 'noData';
        }
      },
       err=>{
         console.log(err);
         this.pageState= '';
      }
    );
  }

  getTypeAllergy(): void{
    this.pageState = 'loading'
    this.getSub =  this.service.getTypeAllergy('allergyintolerances').subscribe(
      result=>{
        if(result?.length > 0){
          this.allergyintolerances = result;
          this.pageState='data';
        } else{
          this.pageState = 'noData';
        }
      },
       err=>{
         console.log(err);
         this.pageState= '';
      }
    );
  }

  getTypeIntolerance():void{
    this.pageState = 'loading'
    this.getSub =  this.service.getTypeIntolerance('allergyintolerances').subscribe(
      result=>{
        if(result?.length > 0){
          this.allergyintolerances = result;
          this.pageState='data';
        } else{
          this.pageState = 'noData';
        }
      },
       err=>{
         console.log(err);
         this.pageState= '';
      }
    );
  }

  openDialogAdd(): void {
    const dialogref = this.dialog.open(AllergyintoleranceAddComponent, {});
    dialogref.afterClosed().subscribe((allergyintolerance: Allergyintolerance): void => {
      console.log(allergyintolerance);
      if (allergyintolerance?.patient) {
        this.service.add('allergyintolerances', allergyintolerance);
      }
    }, err => {
      console.log(err);
    });
  }

  openDialogUpdate(): void {
    const dialogref = this.dialog.open(AllergyintoleranceUpdateComponent, {});
    dialogref.afterClosed().subscribe((allergyintolerance: Allergyintolerance): void => {
      console.log(allergyintolerance);
      if (allergyintolerance?.id) {
        this.service.update('allergyintolerances', allergyintolerance.id, allergyintolerance);
      }
    }, err => {
      console.log(err);
    });
  }

  delete(event: string): void{
    if(confirm("Biztos, hogy ki akarod törölni: "+ event + " ?")) {
      this.service.delete('allergyintolerances', event);
    }
  }

}
