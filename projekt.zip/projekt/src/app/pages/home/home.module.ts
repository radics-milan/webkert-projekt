import { HighLightModule } from './../directive/high-light.module';
import { NavModule } from './../nav/nav.module';
import { HomeRoutingModule } from './home-routing.module';
import { AllergyintoleranceCardModule } from './../allergyintolerance/card/allergyintolerance-card.module';
import { AllergyintoleranceAddModule } from './../allergyintolerance/add/allergyintolerance-add.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { AllergyintoleranceUpdateModule } from './../allergyintolerance/update/allergyintolerance-update.module';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@NgModule({
  declarations: [HomeComponent],
  imports: [
    CommonModule, MatIconModule, MatButtonModule, MatDialogModule, AllergyintoleranceAddModule,
     AllergyintoleranceCardModule, AllergyintoleranceUpdateModule, HomeRoutingModule, NavModule,
     MatProgressSpinnerModule, HighLightModule
  ],
  exports: [HomeComponent]
})
export class HomeModule { }
