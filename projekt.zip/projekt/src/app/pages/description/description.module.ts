import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { NavModule } from './../nav/nav.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DescriptionComponent } from './description.component';
import { DescriptionRoutingModule} from './description-routing.module';
import { MatListModule} from '@angular/material/list'


@NgModule({
  declarations: [
    DescriptionComponent
  ],
  imports: [
    CommonModule, NavModule, DescriptionRoutingModule,
    MatCardModule, MatListModule, MatButtonModule,

  ],
  exports:[DescriptionComponent],
})
export class DescriptionModule { }
