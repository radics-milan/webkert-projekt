import { DescriptionComponent } from './description.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {
      path: '',
      component: DescriptionComponent,
      data: { title: 'Description - Projekt'}
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})


export class DescriptionRoutingModule { }