export const environment = {
  production: false,
  firebaseConfig : {
    /* CONFIG titkos */
  }
};
