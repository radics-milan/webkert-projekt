export const environment = {
 
  firebaseConfig : {
    /* CONFIG titkos */
  },
  production: true
};
